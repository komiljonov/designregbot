## Sketch Recognition on Gradio
This repo contains code to launch a [Gradio](https://github.com/gradio-app/gradio) interface for Sketch Recognition [Gradio Hub](https://hub.gradio.app)

Please see the **original repo**: [trekhleb/machine-learning-experiments](https://github.com/trekhleb/machine-learning-experiments)
<p align="center">
<img src="https://github.com/gradio-app/machine-learning-experiments/blob/master/lightbulb.png?raw=true"/>
</p>
