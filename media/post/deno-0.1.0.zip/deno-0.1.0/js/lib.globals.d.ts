// Copyright 2018 the Deno authors. All rights reserved. MIT license.
// This file contains the default TypeScript libraries for the deno runtime.
/// <reference no-default-lib="true"/>
/// <reference lib="esnext" />
import "gen/js/globals";
