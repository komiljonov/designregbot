// Copyright 2018 the Deno authors. All rights reserved. MIT license.
// Public deno module.
export { exit, readFileSync, writeFileSync } from "./os";
export { libdeno } from "./globals";
