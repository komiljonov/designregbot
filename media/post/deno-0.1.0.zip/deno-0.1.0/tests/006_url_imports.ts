import { printHello } from "http://localhost:4545/tests/subdir/print_hello.ts";
printHello();
console.log("success");
