import * as badModule from "bad-module.ts";
