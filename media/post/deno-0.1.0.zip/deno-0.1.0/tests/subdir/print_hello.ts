export function printHello(): void {
  console.log("Hello");
}
