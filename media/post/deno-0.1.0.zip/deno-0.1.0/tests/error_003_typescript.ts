// console.log intentionally misspelled to trigger TypeScript error
consol.log("hello world!");
