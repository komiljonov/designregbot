import * as deno from "deno";

console.log("before");
deno.exit(42);
console.log("after");
