import { printHello } from "./subdir/print_hello.ts";

printHello();
